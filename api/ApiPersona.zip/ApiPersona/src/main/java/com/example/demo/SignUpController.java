/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import com.example.demo.RepositoryUsuario;
import com.example.demo.Modelousuario;
import org.springframework.web.bind.annotation.RequestBody;

/**
 *
 * @author enoc
 */
public class SignUpController {
     @Autowired
    private RepositoryUsuario repository;

    @PostMapping
    public Boolean post(@RequestBody Modelousuario entity) {
        try {
            repository.save(entity);
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}
