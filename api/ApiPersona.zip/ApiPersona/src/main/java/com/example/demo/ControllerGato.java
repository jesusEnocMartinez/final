/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import com.example.demo.Modelogato;
import com.example.demo.RepositoryGato;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author enoc
 */

@RestController
@RequestMapping("/gatos")
public class ControllerGato {
     @Autowired
    private RepositoryGato repository;

    @GetMapping
    public Iterable<Modelogato> get() {
        return repository.findAll();
    }

    @GetMapping("/{id}")
    public Modelogato getById(@PathVariable Integer id) {
        return repository.findById(id).orElse(null);
    }

    @PostMapping
    public Boolean post(@RequestBody Modelogato entity) {
        try {
            repository.save(entity);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    @PutMapping("/{id}")
    public Boolean put(@PathVariable Integer id, @RequestBody Modelogato entity) {
        try {
            entity.setId(id);
            repository.save(entity);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    @DeleteMapping("/{id}")
    public Boolean delete(@PathVariable Integer id) {
        try {
            repository.deleteById(id);
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}
