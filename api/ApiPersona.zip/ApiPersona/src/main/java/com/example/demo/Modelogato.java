/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.demo;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import org.hibernate.annotations.GenericGenerator;

/**
 *
 * @author enoc
 */
@Entity
@Table(name = "tb_gato")
public class Modelogato {

    @Id
    @GeneratedValue(generator = "increment_gen")
    @GenericGenerator(name = "increment_gen", strategy = "increment")
    private Integer id;
    private String nombre;
    private String raza;

    public Modelogato() {
    }

    public Modelogato(Integer id) {
        this.id = id;
    }

    public Modelogato(Integer id, String email, String clave) {
        this.id = id;
        this.nombre = email;
        this.raza = clave;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getEmail() {
        return nombre;
    }

    public void setEmail(String email) {
        this.nombre = email;
    }

    public String getClave() {
        return raza;
    }

    public void setClave(String clave) {
        this.raza = clave;
    }

    @Override
    public String toString() {
        return "Gato{"
                + "id=" + id
                + ", email='" + nombre + '\''
                + ", clave='" + raza + '\''
                + '}';
    }
}
